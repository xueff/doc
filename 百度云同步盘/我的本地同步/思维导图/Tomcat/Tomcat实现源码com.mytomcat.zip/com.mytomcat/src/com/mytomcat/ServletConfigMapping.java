package com.mytomcat;

import java.util.ArrayList;
import java.util.List;

/**
 * servletӳ���
 * @author ffxue
 *
 */
public class ServletConfigMapping {
	public static List<ServletConfig> configs = new ArrayList<>();
	static{
//		ע������servlet
		configs.add(new ServletConfig("MyServlet","/o","com.mytomcat.MyServlet"));
	}
	public static List<ServletConfig> getConfig(){
		return configs;
	}
	
}
