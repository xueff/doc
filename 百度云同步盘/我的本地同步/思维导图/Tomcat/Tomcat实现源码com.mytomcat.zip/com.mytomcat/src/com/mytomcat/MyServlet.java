package com.mytomcat;

/**
 * servlet ʵ��
 * @author ffxue
 *
 */
public class MyServlet extends AbstractServlet{
	public void doGet(Request request, Response response){
		response.write("GET Response:Hello");
	};
	public void doPost(Request request, Response response){
		response.write("Post Response:Hello");
	};
	
	public void service(Request request, Response response) {
		if("GET".equals(request.getMethod())){
			doGet(request, response);
		}else {
			doPost(request, response);
		}
	}
}
