package com.mytomcat;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
/**
 * 1.����˿�8080
 * 2.��������ServerSocket(8080)��
 * 3.����socket
 * @author ffxue
 *
 */
public class TomcatStart {
	private int port = 8080;
	public TomcatStart() {
	}
	public TomcatStart(int port) {
		this.port = port;
	}
	public static void main(String[] args) throws Exception {
		new TomcatStart().start();
	}

	public void start() throws Exception{
		initServlets();//��ʼ��servlet
		@SuppressWarnings("resource")
		ServerSocket serverSocket = new ServerSocket(port);
		while(true){
			System.out.println("Tomcat start at "+port);
			Socket socket = serverSocket.accept();
			Request request = new Request(socket.getInputStream());
			Response response = new Response(socket.getOutputStream());
//			�ַ�
			dispatch(request,response);
			//			��ӡsocket
			//			TomcatStart.printSocketToString(socket);
			//			socket.getOutputStream().write("helloworld".getBytes());
			socket.close();
	}
		
		
	}
	/**
	 * ��ȡ���õ�servletMap
	 */
	private Map<String, Class<AbstractServlet>> servletMap = new HashMap<>();
	@SuppressWarnings("unchecked")
	private void initServlets() throws ClassNotFoundException  {
		for (ServletConfig config : ServletConfigMapping.getConfig()) {
			servletMap.put(config.getUrlMapping(), (Class<AbstractServlet>)Class.forName(config.getClazz()));
		}
	}

	private void dispatch(Request request, Response response) {
		Class<?> clazz = servletMap.get(request.getUrl());
		MyServlet myServlet;
		try {
			if(null != clazz){
				myServlet = (MyServlet)clazz.newInstance();
				myServlet.service(request, response);
			}else{
				response.write("404 Not Fond");
			}
		} catch (InstantiationException | IllegalAccessException e) {
			response.write("500 internal error \r\n"+Arrays.toString(e.getStackTrace()));
		}
	}

	
	
	
	
	/**
	 * ��ӡsocket
	 * @param socket
	 */
	private /*static*/ void printSocketToString(Socket socket){
		byte[] buf = new byte[1024];
		int len = 0;
		String content = null;
		try {
			if((len=socket.getInputStream().read(buf))>0){
				content = new  String(buf, 0, len);
			}
			System.out.println(content);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
