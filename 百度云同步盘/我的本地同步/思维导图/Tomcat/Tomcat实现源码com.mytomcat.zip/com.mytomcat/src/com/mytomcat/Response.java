package com.mytomcat;

import java.io.IOException;
import java.io.OutputStream;

/**
 *��Ӧ
 * @author ffxue
 *
 */
public class Response {
	private OutputStream out;
	private String url;
	private String method;
	
	public Response(OutputStream out) {
		this.out = out;
	}
	
	public void write(String content) {
		try {
			out.write(content.getBytes());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	

}
