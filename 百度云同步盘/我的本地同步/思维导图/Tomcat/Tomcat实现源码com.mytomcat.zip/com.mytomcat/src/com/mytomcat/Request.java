package com.mytomcat;

import java.io.IOException;
import java.io.InputStream;


/**
 * �������
 * @author ffxue
 *
 */
public class Request {

	private InputStream in;
	private String url;
	private String method;
	
	public Request(InputStream in) {
		this.in = in;
		printOut(in);
	}
	
	/**
	 * ����
	 * @param socket
	 */
	private /*static*/ void printOut(InputStream in){
		byte[] buf = new byte[1024];
		int len = 0;
		String content = null;
		try {
			if((len= in.read(buf))>0){
				content = new  String(buf, 0, len);
			}
			extractField(content);
//			System.out.println(content);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void extractField(String content){
		String command = content.split("\\n")[0];
		String words[] = content.split("\\s");
		setMethod(words[0]);
		System.out.println("*****"+words[0]);
		setUrl(words[1]);
		System.out.println("*****"+words[1]);
	}
	
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}

}
